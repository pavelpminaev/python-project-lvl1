"""module with scripts."""
